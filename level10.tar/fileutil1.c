/*

Name: Dillon Pegany
Description: A program to calculate the shipping fees based on the items that go into the containers.

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fileutil.h"

// Load the text file from the given filename.
// Return a pointer to the array of strings.
// Sets the value of size to be the number of valid
// entries in the array (not the total array length).
char **loadFileAA(char *filename, int *size) {
    
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Cannot open file");
        exit(1);
    }

    //Allocating memory for an array of strings (arr).
    int capacity = 10;
    char **arr = malloc(capacity * sizeof(char *));
    
    if (!arr) {
        perror("Initial malloc failed");
        fclose(file);
        exit(1);
    }

    char buffer[COLS];
    int count = 0;

    //Reading the file line by line.
    while (fgets(buffer, COLS, file)) {
       
        // Trim newline.
        size_t len = strlen(buffer);
        
        if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0';
        }

        //Expanding array if necessary (realloc).
        if (count >= capacity) {
            capacity *= 2;
            char **temp = realloc(arr, capacity * sizeof(char *));
            
            if (!temp) {
                perror("Realloc failed");
                for (int i = 0; i < count; i++) {
                    free(arr[i]);
                }
                free(arr);
                fclose(file);
                exit(1);
            }
            arr = temp;
        }

        //Allocating memory for the string (str).
        arr[count] = malloc(strlen(buffer) + 1);
        
        if (!arr[count]) {
            perror("Malloc for string failed");
            for (int i = 0; i < count; i++) {
                free(arr[i]);
            }
            free(arr);
            fclose(file);
            exit(1);
        }

        //Coping each line into the string (use strcpy).
        strcpy(arr[count], buffer);

        //Attaching the string to the large array (assignment =).
        count++;
    }

    //Closing the file.
    fclose(file);

    //The size should be the number of entries in the array.
    *size = count;

    //Returning pointer to the array of strings.
    return arr;
}

// Search the array for the target string.
// Return the found string or NULL if not found.
char *substringSearchAA(char *target, char **lines, int size) {
    
    for (int i = 0; i < size; i++) {
        if (strstr(lines[i], target)) {
            return lines[i];
        }
    }
    return NULL;
}

//Freeing the memory used by the array
void freeAA(char **arr, int size) {
    
    for (int i = 0; i < size; i++) {
        free(arr[i]);
    }
    free(arr);
}

//The 2D array functions below are unimplemented, as you're using the AA version.
char (*loadFile2D(char *filename, int *size))[COLS] {
    
    *size = 0;
    return NULL;
}

char *substringSearch2D(char *target, char (*lines)[COLS], int size) {
    
    return NULL;
}

void free2D(char (*arr)[COLS]) {
    
    // Nothing to free since it's unimplemented
}