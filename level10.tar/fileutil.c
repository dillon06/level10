/*

Name: Dillon Pegany

Description: a program to calculate the shipping fees based on the items that go into the containers.

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fileutil.h"

// DIRECTIONS
// Choose whether you are doing the 2D array or
// the array of arrays.
// For the 2D array,
//    implement loadFile2D, substringSearch2D, and free2D.
// For the array of arrays, 
//    implement loadFileAA, substringSearchAA, and freeAA.


// Load the text file from the given filename.
// Return a pointer to the array of strings.
// Sets the value of size to be the number of valid
// entries in the array (not the total array length).
char ** loadFileAA(char *filename, int *size)
{
	FILE *file = fopen(filename, "r");
    
	if (!file) {
        
		perror("Cannot open file");
        exit(1);
    }
}
	

	//Allocating memory for an array of strings (arr).
	int capacity = 10;
    char **arr = malloc(capacity * sizeof(char *));
    
	if (!arr) {
        perror("Initial malloc failed");
        fclose(file);
        exit(1);
    }

    char buffer[COLS];
    int count = 0;
	
	//Reading the file line by line.
    while (fgets(buffer, COLS, file)) {
	
	    //Trim newline.
	    size_t len = strlen(buffer);
        
		if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0';
        }
	
	    //Expanding array if necessary (realloc).
	    if (count >= capacity) {
            capacity *= 2;
            char **temp = realloc(arr, capacity * sizeof(char *));
            
			if (!temp) {
                perror("Realloc failed");
                for (int i = 0; i < count; i++) {
                    free(arr[i]);
                }
                free(arr);
                fclose(file);
                exit(1);
            }
            arr = temp;
        }

	    //Allocating memory for the string (str).
	    arr[count] = malloc(strlen(buffer) + 1);
        
		if (!arr[count]) {
            perror("Malloc for string failed");
            for (int i = 0; i < count; i++) {
                free(arr[i]);
            }
            free(arr);
            fclose(file);
            exit(1);
        }

	    //Coping each line into the string (use strcpy).
	    strcpy(arr[count], buffer);
	
	    //Attaching the string to the large array (assignment =).
        count++;
	
	    //Closing the file.
	    fclose(file);
	
	    //The size should be the number of entries in the array.
	    *size = count;
	
	    //Returning pointer to the array of strings.
	    return arr;
   }

char (*loadFile2D(char *filename, int *size))[COLS]
{
	*size = 0;
    return NULL;
}
	// TODO
	// Allocate memory for an 2D array, using COLS as the width.
	// Read the file line by line into a buffer.
    //   Trim newline.
	//   Expand array if necessary (realloc).
	//   Copy each line from the buffer into the array (use strcpy).
    // Close the file.
	
	//The size should be the number of entries in the array.
	*size = 0;
	
	//Returning pointer to the array.
	return NULL;
}

// Search the array for the target string.
// Return the found string or NULL if not found.
char * substringSearchAA(char *target, char **lines, int size)
{
    for (int i = 0; i < size; i++) {
        
		if (strstr(lines[i], target)) {
            return lines[i];
        }
    }
    return NULL;
	
}

char * substringSearch2D(char *target, char (*lines)[COLS], int size)
{
    
    return NULL;
}

//Freeing the memory used by the array
void freeAA(char ** arr, int size)
{
    for (int i = 0; i < size; i++) {
        free(arr[i]);
    }
    free(arr);
}

void free2D(char (*arr)[COLS])
{

}